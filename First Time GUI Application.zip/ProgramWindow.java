/*
 * Me practicing what we went over in class on 9/10/22 (GUI application)
 */

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;

public class ProgramWindow extends JFrame
{
    int winWidth = 500;
    int winHeight = 300;
    
    private int largeFontSize = 30;
    private int mediumFontSize = 20;
    private int gridRows = 6;
    private int gridCols = 2;
    
    public ProgramWindow()
    {
        this.setTitle("My First GUI Window");
        this.setSize(winWidth, winHeight);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        initWin();
        initTextFields();
        initWest();
        initEast();
        initSouth();
        
        this.setVisible (true);
    }
    
    public void initWin()
    {
        Font largeFont = new Font("Arial", 0, largeFontSize);
        JLabel north_lab = new JLabel ("A Marvelous Window");
        JPanel north_pan = new JPanel();
        north_pan.add(north_lab);
        this.add(north_pan, BorderLayout.NORTH);
        north_lab.setFont(largeFont);
        north_pan.setBorder(BorderFactory.createBevelBorder
            (BevelBorder.RAISED));
              
    }
    
    public void initTextFields()
    {
        Font medFont = new Font("Arial", 0, mediumFontSize);
        
        JPanel center_pan = new JPanel(new GridLayout
            (gridRows,gridCols));
        JLabel first_lab = new JLabel("First name: ");
        JLabel last_lab = new JLabel("Last name: ");
        JLabel height_lab = new JLabel("Height: ");
        JLabel age_lab = new JLabel("Age: ");
        JLabel state_lab = new JLabel("State: ");
        JLabel country_lab = new JLabel("Country: ");
        JTextField first_field = new JTextField();
        JTextField last_field = new JTextField();
        JTextField height_field = new JTextField();
        JTextField age_field = new JTextField();
        JTextField state_field = new JTextField();
        JTextField country_field = new JTextField();
        
        center_pan.add(first_lab);
        center_pan.add(first_field);
        center_pan.add(last_lab);
        center_pan.add(last_field);
        center_pan.add(height_lab);
        center_pan.add(height_field);
        center_pan.add(age_lab);
        center_pan.add(age_field);
        center_pan.add(state_lab);
        center_pan.add(state_field);
        center_pan.add(country_lab);
        center_pan.add(country_field);
        
        this.add(center_pan, BorderLayout.CENTER);
        
        first_lab.setFont(medFont);
        last_lab.setFont(medFont);
        height_lab.setFont(medFont);
        age_lab.setFont(medFont);
        state_lab.setFont(medFont);
        country_lab.setFont(medFont);
        
        first_lab.setHorizontalAlignment(JLabel.RIGHT);
        last_lab.setHorizontalAlignment(JLabel.RIGHT);
        height_lab.setHorizontalAlignment(JLabel.RIGHT);
        age_lab.setHorizontalAlignment(JLabel.RIGHT);
        state_lab.setHorizontalAlignment(JLabel.RIGHT);
        country_lab.setHorizontalAlignment(JLabel.RIGHT);
        
        center_pan.setBorder(BorderFactory.createBevelBorder
            (BevelBorder.RAISED));
    }
       
    public void initWest()
    {
        Font biggerRadButFont = new Font ("Arial", 0,
                largeFontSize);
        
        JLabel color_lab = new JLabel("Select a Color");
        
        JRadioButton radBut1 = new JRadioButton("red");
        JRadioButton radBut2 = new JRadioButton("orange");
        JRadioButton radBut3 = new JRadioButton("yellow");
        JRadioButton radBut4 = new JRadioButton("green");
        JRadioButton radBut5 = new JRadioButton("blue");
        JRadioButton radBut6 = new JRadioButton("purple");
        
        radBut1.setFont(biggerRadButFont);
        radBut2.setFont(biggerRadButFont);
        radBut3.setFont(biggerRadButFont);
        radBut4.setFont(biggerRadButFont);
        radBut5.setFont(biggerRadButFont);
        radBut6.setFont(biggerRadButFont);
        
        JPanel west_pan = new JPanel(new GridLayout(7,1));
        
        west_pan.add(color_lab);
        west_pan.add(radBut1);
        west_pan.add(radBut2);
        west_pan.add(radBut3);
        west_pan.add(radBut4);
        west_pan.add(radBut5);
        west_pan.add(radBut6);
        
        this.add(west_pan, BorderLayout.WEST);
        
        ButtonGroup group = new ButtonGroup();
        group.add(radBut1);
        group.add(radBut2);
        group.add(radBut3);
        group.add(radBut4);
        group.add(radBut5);
        group.add(radBut6);
        
        west_pan.setBorder(BorderFactory.createBevelBorder
            (BevelBorder.RAISED));
        }
    
        public void initEast()
        {
            Font bigCheckBoxFont = new Font ("Arial", 0,
                    largeFontSize);
                    
            
            JLabel feel_lab = new JLabel("How do you feel");
            
            
            JCheckBox box_1 = new JCheckBox("Happy");
            JCheckBox box_2 = new JCheckBox("Mad");
            JCheckBox box_3 = new JCheckBox("Anxious");
            JCheckBox box_4 = new JCheckBox("Sleepy");
            JCheckBox box_5 = new JCheckBox("Excited");
            JCheckBox box_6 = new JCheckBox("Motivated");
            JCheckBox box_7 = new JCheckBox("Other");
            
            box_1.setFont(bigCheckBoxFont);
            box_2.setFont(bigCheckBoxFont);
            box_3.setFont(bigCheckBoxFont);
            box_4.setFont(bigCheckBoxFont);
            box_5.setFont(bigCheckBoxFont);
            box_6.setFont(bigCheckBoxFont);
            
            JPanel east_pan = new JPanel(new GridLayout(8,1));
                
            east_pan.add(feel_lab);
            east_pan.add(box_1);
            east_pan.add(box_2);
            east_pan.add(box_3);
            east_pan.add(box_4);
            east_pan.add(box_5);
            east_pan.add(box_6);
            east_pan.add(box_7);

            this.add(east_pan, BorderLayout.EAST);
            
            east_pan.setBorder(BorderFactory.createBevelBorder
                (BevelBorder.RAISED));
        }
        
        public void initSouth()
        {
            Font southButFont = new Font ("Arial", 0,
                    largeFontSize);
            
            JButton clear_but = new JButton("clear");
            JButton submit_but = new JButton("submit");
            JButton exit_but = new JButton ("exit");
            
            clear_but.setFont(southButFont);
            submit_but.setFont(southButFont);
            exit_but.setFont(southButFont);
                    
            
            JPanel south_pan = new JPanel();
            
            south_pan.add(clear_but);
            south_pan.add(submit_but);
            south_pan.add(exit_but);
            
            this.add(south_pan, BorderLayout.SOUTH);
            
            south_pan.setBorder(BorderFactory.createBevelBorder
                (BevelBorder.RAISED));
        }
    
        public static void main(String[] args) 
    {
        new ProgramWindow();
    }
}
